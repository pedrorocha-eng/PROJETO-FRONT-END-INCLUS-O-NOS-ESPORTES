# Deploy com HTTPS (GitHub Pages)

O GitHub Pages serve o site com **HTTPS gratuito e automático**.

## Passo a passo
1. Crie um repositório público no GitHub chamado `esportes-sem-limites`.
2. Envie o projeto:
   ```bash
   git remote add origin https://github.com/SEU-USUARIO/esportes-sem-limites.git
   git push -u origin main
   ```
3. No GitHub: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. A aba **Actions** roda o workflow "Validar e publicar" (validação W3C + deploy).
5. Quando terminar, o site estará em `https://SEU-USUARIO.github.io/esportes-sem-limites/`.
6. Em **Settings → Pages**, confirme que **Enforce HTTPS** está marcado.
7. Atualize o link no `README.md`.

## Alternativas
- **Netlify** ou **Vercel**: arrastar a pasta ou conectar o repositório; também com HTTPS automático. Úteis se quiserem ativar o modo LLM da assistente (funções serverless).

## Evidências para a entrega
- Print da URL com o cadeado 🔒 no navegador.
- Print do workflow verde na aba Actions.
