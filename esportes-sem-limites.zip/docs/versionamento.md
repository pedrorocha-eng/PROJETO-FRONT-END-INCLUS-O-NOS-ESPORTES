# Versionamento (Git + GitHub)

## Fluxo
- `main`: versão estável, publicada automaticamente.
- Branches de funcionalidade: `feat/nome`, `fix/nome`, `docs/nome` → Pull Request → revisão de um colega → merge.
- Cada PR roda a validação W3C no GitHub Actions.

## Padrão de commits (Conventional Commits)
```
feat: adiciona simulador de doação
fix: corrige blocos condicionais do formulário
docs: atualiza diário de bordo
style: ajusta espaçamento do menu
refactor: extrai validação para função genérica
```

## Tags de versão
- `v1.0-mvp`: 1ª entrega *(criar no commit correspondente, se existir)*
- `v2.0`: entrega final

```bash
git tag -a v2.0 -m "Entrega final"
git push origin --tags
```

## Dicas para a avaliação
- Faça commits pequenos e frequentes, **de todos os integrantes**.
- Use Issues para registrar tarefas e bugs e ligue-as aos PRs (`Closes #3`).
