# Escopo, objetivos e critérios de aceitação

## Problema
Pessoas com deficiência têm pouco acesso ao esporte por barreiras **informacionais** (não sabem o que existe nem onde praticar), **atitudinais** (capacitismo), **econômicas** (equipamentos caros) e **arquitetônicas**. ONGs pequenas também não têm canal digital acessível para captar atletas, voluntários e doações.

## Público-alvo
1. Pessoas com deficiência (e familiares) que querem praticar esporte.
2. Voluntários (professores, estudantes, intérpretes de Libras, atletas-guia).
3. Doadores e empresas parceiras.
4. Educadores e público geral interessados no tema.

## Objetivo geral
Criar a interface de um site informativo e acessível que **eduque sobre o esporte inclusivo** e ofereça **ferramentas digitais para a ONG** captar participantes, voluntários e recursos.

## Objetivos específicos e critérios de aceitação

| # | Objetivo / requisito | Critério de aceitação | Status | Onde verificar |
|---|---|---|---|---|
| RF01 | Informar sobre o tema em todas as páginas | Cada uma das 10 páginas tem ao menos uma seção de conteúdo sobre inclusão/paradesporto | ✅ | todas |
| RF02 | Apresentar modalidades adaptadas | ≥ 8 modalidades com público indicado e regras; filtro por deficiência/estilo; busca textual | ✅ 10 | modalidades.html |
| RF03 | Inscrição de atleta/voluntário | Campos condicionais por perfil; validação; protocolo gerado; registro salvo | ✅ | participe.html |
| RF04 | Doação | Valores pré-definidos + outro valor (mín. R$ 5); impacto exibido por valor; histórico | ✅ | doe.html |
| RF05 | Agenda de eventos | Filtro por tipo; salvar eventos em "Minha agenda" persistente | ✅ | eventos.html |
| RF06 | Contato e FAQ | FAQ pesquisável; formulário validado; preferência de resposta (incl. Libras) | ✅ | contato.html |
| RF07 | Assistente com IA | Responde ≥ 20 temas; não inventa respostas fora da base; histórico apagável | ✅ 24 temas | assistente.html |
| RF08 | Recomendador de modalidade | 3 perguntas → 3 modalidades justificadas | ✅ | assistente.html#recomendador |
| RF09 | Impacto/ODS | ODS relacionados com metas e progresso; compromissos do visitante | ✅ 7 ODS | impacto.html |
| RF10 | Busca no site | Resultados ao digitar 2+ letras; fallback para a assistente | ✅ | cabeçalho |
| RNF01 | HTML semântico e válido | 0 erros no validador W3C nas 10 páginas | ✅ | testes.md |
| RNF02 | Acessibilidade | WCAG 2.2 AA; 0 violações no axe-core; navegável só por teclado | ✅ | acessibilidade.md |
| RNF03 | Responsividade | Sem rolagem horizontal de 320 px a 1920 px; menu hambúrguer < 1180 px | ✅ | previews/ |
| RNF04 | Persistência | Preferências, rascunhos e registros sobrevivem ao recarregar | ✅ | localStorage (prefixo `esl:`) |
| RNF05 | Publicação | Site no ar com HTTPS | ⏳ após o push | deploy.md |
| RNF06 | Desempenho/sustentabilidade | Sem frameworks; site inteiro (10 páginas + CSS + JS) < 250 KB, ≈ 45 KB comprimido | ✅ | ods-impacto.md |
| RNF07 | Privacidade (LGPD) | Consentimento explícito; nenhum dado enviado a servidor | ✅ | participe.html |

## Fora do escopo
Back-end, banco de dados, pagamento real, autenticação e envio real de e-mails — o projeto é **somente interface**. As funcionalidades simulam o fluxo e armazenam dados no `localStorage`.
