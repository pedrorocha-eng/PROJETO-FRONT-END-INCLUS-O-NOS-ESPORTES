# Diário de bordo

> Registre aqui cada sessão de trabalho: **data, o que foi feito, problemas encontrados, como foram resolvidos e próximos passos**. As entradas de 1ª entrega (MVP) devem ser preenchidas pela equipe com o histórico real.

---

## [DATA DA 1ª ENTREGA] — MVP *(preencher)*
- **Feito:** …
- **Feedback recebido do professor/ONG:** …
- **Próximos passos:** …

---

## 13/11/2026 — Reestruturação completa (versão 2)

**Feito**
- Definição do nome **Esportes sem Limites** e reescrita do escopo com critérios de aceitação mensuráveis (`escopo-e-criterios.md`).
- Adoção de um design system monocromático de "galeria de performance atlética": preto `#111`, branco, três cinzas, botões em pílula (30 px), cards de cantos retos, heros escuros em tela cheia, sem sombras.
- Expansão para **10 páginas** com conteúdo real sobre paradesporto (história, classificação funcional, legislação, linguagem anticapacitista).
- JavaScript: validação acessível, rascunho automático, filtros, favoritos, agenda pessoal, simulador de doação, busca no site.
- Assistente IA "Tina" + recomendador de modalidade.
- Workflow do GitHub Actions: validação W3C automática + deploy no GitHub Pages.

**Problemas e soluções**
| Problema | Causa | Solução |
|---|---|---|
| Cinza `#9e9ea0` do design tem contraste 2,6:1 | Não atinge WCAG AA (4,5:1) | Usado só como decoração; textos secundários em `#707072` (4,9:1) |
| Design pede links sem sublinhado | Viola WCAG 1.4.1 (cor como único indicador) | Links em texto corrido sublinhados; navegação usa borda inferior |
| Widget VLibras usa atributo `vw`, inválido no W3C | Marcação proprietária | Marcação injetada via JavaScript (`vlibras.js`) |
| Botão contornado invisível sobre o hero escuro | Cor herdada do tema claro | Regra específica para fundos escuros |
| Blocos "atleta" e "voluntário" apareciam juntos | `display: grid` sobrescrevia o atributo `hidden` | `[hidden] { display: none !important; }` |
| Menu quebrava em 2 linhas em 1440 px | 10 links + busca | Ajuste de espaçamento e hambúrguer abaixo de 1180 px |

**Testes:** W3C 0 erros · axe-core 0 violações · sem rolagem horizontal no iPhone 13.

**Próximos passos:** publicar no GitHub Pages, testar com leitor de tela (NVDA) e coletar feedback de pessoas com deficiência.

---

## 13/11/2026 — Navegação mobile refeita

**Feito**
- Menu mobile virou **painel de tela cheia** com busca, links grandes, indicador da página atual e ícone hambúrguer que se transforma em "X".
- Cabeçalho **fixo e compacto** no mobile; a barra local deixou de ocupar espaço ao rolar.
- Ajustes de acessibilidade agrupados em um botão **"Acessibilidade"** com painel em grade.
- Acessibilidade do menu: foco no item atual, Tab circular, Esc fecha, fundo `inert` e rolagem travada.
- Criado teste automatizado (10 páginas × 3 aparelhos) — ver `testes.md`.

**Problemas e soluções**
| Problema | Causa | Solução |
|---|---|---|
| Logo e links encostados na borda | `.nav { padding: 4px 0 }` zerava o padding lateral do container | Regras reescritas sem sobrescrever o gutter |
| Barra local presa no topo ocupava ~1/6 da tela | `position: sticky` também no mobile | Fixo só o cabeçalho; barra local rola normalmente |
| Rolagem lateral em 320 px em todas as páginas | Itens de grid com `min-width: auto` não encolhiam | `minmax(0, 1fr)` + `min-width: 0` nos itens |
| Chat com 731 px de largura | Sugestões com `nowrap` esticavam a coluna | Mesmo ajuste de grid |
| Lupa "pulava" ao exibir resultados da busca | Posicionada a 50% do formulário inteiro | Posição fixa no centro do campo |
| Aviso sobreposto ao botão da IA | Ambos no rodapé da tela | Aviso posicionado acima do botão |

**Testes:** 30/30 combinações página × aparelho OK · W3C 0 erros · axe 0 violações.

---

## 13/11/2026 — Troca do acento para verde-oliva

**Feito**
- Geradas previews comparando 4 tons: `#00d959` (atual), `#00a344`, `#0a7d3b` e `#7e8100`.
- Escolhido o **verde-oliva `#7e8100`**, aplicado puro em botões, links, números, foco e item ativo.
- Botões e tags com texto **preto** (contraste 5,0:1; com branco seria 4,2:1, reprovado).
- Tons derivados para acessibilidade: `#5a5c00` em superfícies claras e `#e0e300` no alto contraste.

**Problemas e soluções**
| Problema | Solução |
|---|---|
| Tags com texto oliva sobre fundo oliva translúcido reprovaram no axe (contraste) | Tags com fundo oliva sólido e texto preto |
| `#7e8100` fica no limite do AA (4,5:1) | Documentado em `identidade-visual.md`; usado só sobre `#111`/`#000` |

**Testes:** W3C 0 erros · axe-core 0 violações nas 10 páginas (também no modo claro e no alto contraste).

---

## 13/11/2026 — Nova identidade visual (v3)

**Feito**
- Troca do design monocromático claro por um tema **escuro**: palco preto, cards com cantos de 28 px, botões em pílula, títulos grandes em peso 600.
- Adoção do **verde** (`#00d959`) como único acento: botões, links, foco, item ativo e todos os números/métricas.
- Remoção de todas as ilustrações decorativas: o site passa a ser **100% informativo, sem imagens**.
- Novo cabeçalho em duas barras: navegação global (44 px) e barra local com o título da página e os ajustes de acessibilidade (fixa ao rolar).
- Home redesenhada: hero centralizado com métricas, tiles numéricos (10 modalidades, 2 formas de participar, R$ 5, 24 temas da IA).
- Botão "Modo escuro" virou **"Modo claro"**, já que o padrão agora é escuro.

**Problemas e soluções**
| Problema | Solução |
|---|---|
| Azul de link do design (`#0066cc`) tem contraste baixo no fundo escuro (≈ 3,6:1) | Links em verde claro `#5cf08f` (12:1) |
| Rótulo "Tina" do chat com contraste 3,6:1 no balão cinza (axe) | Cor trocada para branco 80% |
| Links do menu ficaram sublinhados pela regra de links em texto | Regra limitada ao conteúdo (`main`) |

**Testes:** W3C 0 erros · axe-core 0 violações nas 10 páginas · sem rolagem horizontal no iPhone 13.

---

## Modelo para novas entradas
```
## DD/MM/AAAA — Título
**Feito:**
**Problemas e soluções:**
**Uso de IA nesta sessão:** (ferramenta, para quê, o que foi revisado/alterado)
**Próximos passos:**
```
