# Melhorias desde o MVP (1ª entrega)

> ⚠️ Ajuste a coluna "MVP" para refletir exatamente o que sua equipe entregou na 1ª entrega.

| Aspecto | MVP (1ª entrega) | Versão atual | Por quê |
|---|---|---|---|
| Páginas | *ex.: 3–4 páginas* | **10 páginas** com conteúdo informativo em todas | Cobrir o tema e as necessidades da ONG |
| Identidade visual | *ex.: estilos soltos* | Design system escuro com acento verde, tokens CSS e componentes documentados | Consistência, contraste e manutenção |
| Responsividade | *ex.: parcial* | Mobile-first, 3 breakpoints, menu hambúrguer acessível | Uso real em celular |
| JavaScript | *ex.: nenhum/menu* | Validação, localStorage, filtros, busca, simuladores | Funcionalidades para a ONG |
| Acessibilidade | *ex.: alt e labels* | WCAG 2.2 AA, barra de ajustes, VLibras, axe 0 violações | Público-alvo são pessoas com deficiência |
| IA | *ex.: não havia* | Assistente "Tina" + recomendador + doc de IA no processo | Critério 8 |
| Validação W3C | *ex.: não testado* | 0 erros e checagem automática no CI | Critério 2 |
| Deploy | *ex.: local* | GitHub Pages com HTTPS e deploy automático | Critério 5 |
| Documentação | *ex.: README simples* | `/docs` completa + diário de bordo | Critério 11 |
| ODS | *ex.: citado* | 7 ODS com metas, sustentabilidade do próprio site | Critério 12 |

## Feedbacks atendidos
- [ ] *Feedback 1 recebido na 1ª entrega → como foi resolvido*
- [ ] *Feedback 2 → …*
