# Documentação — Esportes sem Limites

| Documento | Conteúdo | Critério da rubrica |
|---|---|---|
| [escopo-e-criterios.md](escopo-e-criterios.md) | Problema, público, objetivos, requisitos e **critérios de aceitação** | 6, 7 |
| [diario-de-bordo.md](diario-de-bordo.md) | Registro datado de decisões, problemas e soluções | 11 |
| [melhorias-mvp.md](melhorias-mvp.md) | O que mudou desde a 1ª entrega | 9 |
| [identidade-visual.md](identidade-visual.md) | Design system, tokens, componentes, responsividade | 3 |
| [acessibilidade.md](acessibilidade.md) | Checklist WCAG 2.2 AA e recursos implementados | 4 |
| [uso-de-ia.md](uso-de-ia.md) | IA no produto (assistente) e IA no processo de desenvolvimento | 8 |
| [testes.md](testes.md) | Validação W3C, auditoria axe, testes manuais | 2, 4, 7 |
| [deploy.md](deploy.md) | Publicação com HTTPS no GitHub Pages | 5 |
| [versionamento.md](versionamento.md) | Fluxo de Git/GitHub, padrão de commits | 10 |
| [ods-impacto.md](ods-impacto.md) | ODS, sustentabilidade e impacto social | 12 |
| [previews/](previews/) | Capturas de tela do site | — |
