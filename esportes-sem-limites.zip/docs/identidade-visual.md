# Identidade visual (v3)

**Conceito:** "instrumento de resistência à meia-noite". O site é uma sequência de salas escuras onde títulos grandes e números em **verde-oliva** contam a história do esporte inclusivo, como os dados de desempenho em um painel esportivo. **Não usamos fotos nem ilustrações**: a informação é a protagonista, o que também deixa o site leve e independe de direitos de imagem.

## Paleta
| Token | Valor | Uso | Contraste |
|---|---|---|---|
| Carbon | `#111111` | Fundo da página, barras de navegação | — |
| Absolute Black | `#000000` | Palco dos heros, cards e tiles | — |
| Graphite | `#1d1d1f` | Superfícies internas; texto sobre faixas claras | 16:1 sobre `#f5f5f7` |
| Polar White | `#f5f5f7` | Texto principal; rodapé claro | 17,9:1 sobre `#111` |
| Steel | `#86868b` | Texto secundário | 5,6:1 sobre `#111` ✅ |
| Divider Gray | `#6e6e73` | Bordas de campos (≥ 3:1, WCAG 1.4.11) | 3,6:1 sobre `#111` |
| Control Charcoal | `#333336` | Chips, linhas do acordeão, balões do chat | — |
| **Verde-oliva** | `#7e8100` | Acento único: botões, links, números, foco, item ativo | 4,5:1 sobre `#111` ✅ AA |
| Texto sobre o oliva | `#000000` | Rótulos de botões e tags | 5,0:1 ✅ (branco daria só 4,2:1 ✖) |
| Oliva escuro | `#5a5c00` | Oliva sobre fundos claros (rodapé, modo claro) | 6,5:1 sobre `#f5f5f7` ✅ |
| Oliva-amarelo | `#e0e300` | Acento no modo alto contraste | 15:1 sobre `#000` ✅ |

**Regra do verde-oliva:** ele é o único acento cromático e sinaliza o que é *ação* (botões, links, item ativo, foco) ou *dado* (métricas, números dos ODS, linha do tempo). O resto é preto, branco e cinza.

## Tipografia
**Inter** (substituta livre da SF Pro), pesos 400 e 600.
| Papel | Tamanho | Peso |
|---|---|---|
| Navegação global | 12 px | 400 |
| Corpo | 17 px / 1,47 | 400 |
| Título da barra local | 17 px | 600 |
| Títulos de card | 19 px | 600 |
| Títulos de seção | 28–48 px | 600 |
| Métricas | 48 px, verde | 600 |
| Hero | até 64 px, caixa alta, `line-height 1.06` | 600 |

Tudo em `rem`: respeita o zoom do navegador e o botão A+.

## Formas e superfícies
- Cards, tiles, tabelas e chat: **raio de 28 px**, sem sombras.
- Botões e campos de texto: **pílula (980 px)**. Chips e linhas do acordeão: 36 px.
- Profundidade criada só pela alternância `#111` (página) → `#000` (palco/cards) → `#f5f5f7` (rodapé).

## Componentes
Barra global de 44 px · barra local de 52 px (título da página + ajustes de acessibilidade, fixa ao rolar) · hero centralizado com faixa de métricas · tiles numéricos 2×2 · cards de métrica · acordeão em pílulas com glifo "+" circular · chips de filtro · linha do tempo com anos em verde · formulários em pílula · chat com balões · rodapé claro em 4 colunas.

## Responsividade e navegação mobile
| Faixa | Comportamento |
|---|---|
| > 1080 px | Navegação completa em uma linha + busca; barra local (título + acessibilidade) fixa ao rolar |
| ≤ 1080 px | **Cabeçalho compacto fixo** (56 px) com botão "Menu" (ícone que vira "X"). O menu abre em **painel de tela cheia** com busca no topo, links grandes (alvos de 56 px), item atual destacado com "●". A barra local deixa de ser fixa e os ajustes de acessibilidade ficam num botão **"Acessibilidade"** que abre um painel em grade 2×4 |
| ≤ 860 px | Layouts lado a lado viram 1 coluna |
| ≤ 640 px | Tiles, formulários e rodapé em 1 coluna; botão da IA compacto; avisos acima do botão da IA |
| ≤ 420 px | Grade da equipe em 1 coluna; números menores |
| ≤ 360 px | Botão do menu só com ícone (rótulo continua disponível para leitores de tela) |

Todas as grades usam `minmax(0, 1fr)`, permitindo que os itens encolham sem criar rolagem horizontal, mesmo em telas de 320 px.

## Modos de acessibilidade
- **Modo claro:** inverte para fundo `#f5f5f7` com oliva escuro `#5a5c00`.
- **Alto contraste:** preto puro, branco puro, oliva-amarelo `#e0e300` e foco amarelo.

> **Atenção:** o `#7e8100` está exatamente no limite do contraste AA (4,5:1) sobre `#111`. Não o use sobre fundos mais claros que `#111` (por exemplo, `#1d1d1f` ou `#333336`) para textos pequenos.
