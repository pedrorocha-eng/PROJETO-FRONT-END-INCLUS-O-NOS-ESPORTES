# Testes e validação

## Validação W3C (HTML e CSS)
Ferramenta: **Nu HTML Checker (vnu.jar)**, o mesmo motor de https://validator.w3.org/nu/.

```bash
npm run validar
```
(Requer Java instalado. O comando baixa o validador e checa todas as páginas e o CSS.)
Resultado (13/11/2026): **0 erros nas 10 páginas e no CSS.** Únicos avisos informativos: suporte ao atributo `inputmode`, que é intencional (melhora o teclado no celular).
O workflow `.github/workflows/pages.yml` repete a validação **a cada push**; se houver erro, o deploy é bloqueado.

Para validar online: abra cada página publicada em https://validator.w3.org/nu/?doc=URL_DA_PAGINA e tire um print para o relatório.

## Acessibilidade automatizada
Ferramenta: **axe-core 4.10** (regras WCAG 2.0/2.1/2.2 A e AA), executada via Playwright em todas as páginas.
Resultado: **0 violações nas 10 páginas.**

## Testes funcionais (manuais / Playwright)
| Caso | Passos | Esperado | OK |
|---|---|---|---|
| Validação de inscrição | Enviar formulário vazio | Resumo de erros focado; mensagens por campo | ✅ |
| Campos condicionais | Alternar Atleta/Voluntário | Só o bloco do perfil aparece e é obrigatório | ✅ |
| Rascunho | Digitar, recarregar a página | Dados restaurados + aviso | ✅ |
| Filtro de modalidades | Clicar "Deficiência visual" | 5 resultados; contador anunciado | ✅ |
| Favoritos | Salvar Goalball, recarregar | Continua salvo | ✅ |
| Agenda | "Tenho interesse" | Evento aparece em "Minha agenda" | ✅ |
| Doação | Escolher "Outro" com R$ 2 | Erro "mínimo R$ 5,00" | ✅ |
| Assistente | Perguntar "O que é goalball?" | Resposta + link | ✅ |
| Assistente (fora da base) | Perguntar sobre receita de bolo | Não inventa; encaminha ao contato | ✅ |
| Alto contraste | Clicar no botão e recarregar | Tema mantido | ✅ |
| Responsivo | iPhone 13 (390 px) | Sem rolagem horizontal; menu hambúrguer | ✅ |

## Teste automatizado de navegação mobile
Script Playwright que percorre **as 10 páginas em 3 aparelhos** (iPhone SE 320 px, iPhone 13 390 px, iPad Mini 768 px) e verifica:

| Verificação | Resultado |
|---|---|
| Sem rolagem horizontal | ✅ 30/30 |
| Menu abre: `aria-expanded`, painel visível, rolagem travada, conteúdo `inert` | ✅ 30/30 |
| Foco vai para o item da página atual | ✅ 30/30 |
| Último item do menu alcançável rolando o painel | ✅ 30/30 |
| Esc fecha o menu e devolve o foco ao botão | ✅ 30/30 |
| Painel de acessibilidade abre, funciona e fecha com Esc | ✅ 30/30 |
| Cabeçalho permanece fixo ao rolar | ✅ 30/30 |
| axe-core (WCAG 2.2 AA) sem violações | ✅ 30/30 |

Problemas encontrados e corrigidos por este teste: rolagem lateral em 320 px (rodapé, grade da equipe, cards de eventos), chat esticado até 731 px pelas sugestões, cards de modalidades com largura mínima maior que a tela, tabelas e chat com rolagem sem foco de teclado.

## Navegadores
Chromium (Playwright). Recomenda-se testar também Firefox, Safari (iOS) e Chrome Android antes da apresentação.
