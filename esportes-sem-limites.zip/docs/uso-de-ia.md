# Uso e integração de IA

A IA aparece em duas frentes: **no produto** (funcionalidades para o visitante) e **no processo** (como a equipe usou IA para desenvolver).

## 1. IA no produto

### Assistente virtual "Tina" (`assets/js/ia.js`, página `assistente.html`)
Funciona em duas camadas:

**Camada 1: modo local (padrão, ativo no site publicado)**
- Base de conhecimento com **24 tópicos** escritos e revisados pela equipe (modalidades, classificação, leis, ODS, como participar etc.).
- Motor de **recuperação de informação**: normalização (sem acentos), remoção de *stopwords*, dicionário de sinônimos ("cadeirante" → "cadeira de rodas", "cego" → "deficiência visual"), *stemming* simplificado e pontuação de similaridade entre a pergunta e cada tópico.
- **Limiar de confiança**: abaixo de 0,28 a Tina *não inventa resposta* e encaminha para um humano (mitiga "alucinação").
- Cada resposta traz um link para a página com a informação completa.
- Histórico salvo apenas no `localStorage` e com botão "Limpar conversa" (LGPD).
- Métrica local de perguntas sem resposta (`esl:chat-metricas`), usada para ampliar a base.
- Integração com o site: a busca do cabeçalho manda para a assistente quando nada é encontrado (`assistente.html?q=...`), e cada card de modalidade tem "Perguntar à IA".

**Camada 2: modo LLM (opcional, pronto para ligar)**
Se a variável global `window.MT_IA_ENDPOINT` for definida, a pergunta vai para um **backend próprio** (ex.: função serverless na Vercel, Netlify ou Cloudflare Workers) que chama um modelo de linguagem. Se a chamada falhar, o modo local assume (*fallback*).

Contrato da API:
```http
POST /api/assistente
Content-Type: application/json

{ "question": "O que é bocha?", "history": [ { "role": "user", "html": "..." } ] }

→ 200 { "answer": "A bocha paralímpica é ..." }
```
> 🔒 **A chave da API nunca fica no front-end.** Ela vive só nas variáveis de ambiente do backend. O backend deve receber um *system prompt* com as regras: responder só sobre esporte inclusivo, usar linguagem sem capacitismo, não dar diagnósticos e citar as páginas do site.

### Recomendador de modalidade
Sistema especialista baseado em regras ponderadas: 3 perguntas (perfil, estilo coletivo/individual, ritmo) → pontuação → as 3 melhores modalidades, com justificativa. Deixa claro que a indicação final é feita por profissionais.

### Princípios éticos adotados
Sem diagnóstico · revisão humana do conteúdo · privacidade por padrão · transparência (página explica como a IA funciona) · linguagem inclusiva.

## 2. IA no processo de desenvolvimento

| Etapa | Ferramenta | Como foi usada | Revisão humana |
|---|---|---|---|
| Estrutura e código | Claude (Anthropic) | Geração da base de HTML/CSS/JS a partir do design de referência e da rubrica | *Preencher: o que a equipe revisou/alterou* |
| Conteúdo | Claude | Rascunho de textos sobre paradesporto | Conferência de datas e números em fontes oficiais (IBGE, CPB, IPC, legislação) |
| Acessibilidade | axe-core + Nu HTML Checker | Auditoria automática | Testes manuais de teclado e leitor de tela |
| *Outras* | *…* | *…* | *…* |

> ✍️ **Boa prática acadêmica:** registre no diário de bordo cada uso de IA (prompt resumido, o que foi aproveitado, o que foi corrigido). A IA acelera o trabalho, mas a responsabilidade pelo conteúdo é da equipe.
