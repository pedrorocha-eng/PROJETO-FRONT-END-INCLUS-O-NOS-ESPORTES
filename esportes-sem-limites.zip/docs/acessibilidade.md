# Acessibilidade (WCAG 2.2 nível AA)

O público principal do site são pessoas com deficiência, então a acessibilidade é requisito central.

## Recursos implementados
| Recurso | Critério WCAG | Onde |
|---|---|---|
| `lang="pt-BR"` e títulos únicos por página | 3.1.1, 2.4.2 | todas |
| Link "Pular para o conteúdo" | 2.4.1 | topo |
| Landmarks: `header`, `nav` (rotulado), `main`, `footer`, `aside`, `search` | 1.3.1 | todas |
| Hierarquia de títulos h1 → h2 → h3 sem saltos | 1.3.1, 2.4.6 | todas |
| Navegação 100% por teclado; menu fecha com Esc; busca com seta ↓ | 2.1.1 | todas |
| Menu mobile: foco vai para o item atual ao abrir, fica preso no menu (Tab circular), volta ao botão ao fechar; o resto da página fica `inert` e a rolagem do fundo é travada | 2.4.3, 2.1.2 | ≤ 1080 px |
| Botões do menu e do painel de acessibilidade com `aria-expanded` e `aria-controls` | 4.1.2 | ≤ 1080 px |
| Tabelas e histórico do chat com rolagem focáveis pelo teclado (`tabindex="0"`) | 2.1.1 | sobre, paradesporto, assistente |
| Sem rolagem horizontal de 320 px a 1920 px | 1.4.10 | todas |
| Foco visível de 3 px em todos os interativos | 2.4.7, 2.4.11 | CSS |
| Contraste ≥ 4,5:1 (texto) e ≥ 3:1 (bordas de campos) | 1.4.3, 1.4.11 | tokens |
| barra de ajustes: A+/A− (até 150%), alto contraste, modo claro, espaçar texto, pausar animações | 1.4.4, 1.4.12, 2.3.3 | topo |
| Preferências persistidas no `localStorage` e aplicadas antes da renderização | — | `<head>` |
| Respeita `prefers-reduced-motion` e `prefers-color-scheme` | 2.3.3 | CSS |
| Alvos de toque ≥ 44 px (botões) | 2.5.8 | CSS |
| Formulários: `label` associado, `fieldset/legend`, `autocomplete`, dicas com `aria-describedby` | 1.3.1, 1.3.5, 3.3.2 | formulários |
| Erros em texto + ícone, `aria-invalid`, resumo de erros com links que focam o campo | 3.3.1, 3.3.3 | `main.js` |
| Mensagens dinâmicas com `role="status"`/`aria-live` (toasts, contadores, chat) | 4.1.3 | JS |
| Botões de alternância com `aria-pressed` | 4.1.2 | filtros, favoritos |
| Links em texto corrido sublinhados (não depende só de cor) | 1.4.1 | CSS |
| Tabelas com `caption` e `scope` | 1.3.1 | sobre, paradesporto |
| Acordeões nativos `details/summary` | 2.1.1, 4.1.2 | FAQ, mitos |
| Imagens decorativas com `aria-hidden="true"` | 1.1.1 | SVGs |
| Tradução em Libras (VLibras) | boa prática eMAG | todas |

## Desvios conscientes do design de referência
- O design pedia links sem sublinhado → sublinhamos links em texto corrido (WCAG 1.4.1).
- Cinza `#9e9ea0` não é usado em texto (contraste insuficiente).

## Como testar
1. Navegue só com **Tab / Shift+Tab / Enter / Espaço / Esc**.
2. Leitor de tela: NVDA (Windows) ou VoiceOver (macOS/iOS).
3. Zoom do navegador em 200% e botão A+ no máximo.
4. Extensões: axe DevTools, WAVE, Lighthouse.
