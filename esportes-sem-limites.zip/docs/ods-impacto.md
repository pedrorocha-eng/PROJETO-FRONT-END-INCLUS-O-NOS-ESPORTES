# ODS, sustentabilidade e impacto social

## ODS atendidos
| ODS | Como o projeto contribui |
|---|---|
| 3 · Saúde e bem-estar | Promove atividade física para pessoas com deficiência |
| 4 · Educação de qualidade | Conteúdo educativo sobre paradesporto; formação de professores |
| 5 · Igualdade de gênero | Meta de 50% de atletas mulheres; roda de conversa sobre mulheres no paradesporto |
| 10 · Redução das desigualdades | Acesso gratuito e site acessível para quem costuma ficar de fora |
| 11 · Cidades sustentáveis | Mapeamento e advocacy por espaços esportivos acessíveis |
| 12 · Consumo responsável | Doação e reuso de equipamentos esportivos (economia circular) |
| 17 · Parcerias | Rede com escolas, universidades, poder público e empresas |

A Agenda 2030 da ONU (parágrafo 37) reconhece o esporte como "importante facilitador" do desenvolvimento sustentável.

## Impacto social
- **Informação acessível:** combate o capacitismo, ensina a linguagem correta e divulga direitos (LBI, Convenção da ONU).
- **Conexão:** reduz a distância entre quem quer praticar, quem quer ajudar e a ONG.
- **Inclusão digital:** o site é utilizável por pessoas cegas, surdas, com baixa visão, deficiência motora ou cognitiva.

## Sustentabilidade digital do site
- Zero frameworks e zero dependências de produção: menos dados transferidos e menos energia gasta.
- Nenhuma foto ou ilustração: só texto e CSS, o que reduz muito o peso das páginas; fontes com `display=swap`.
- Sem rastreadores ou cookies de publicidade; dados ficam no dispositivo.
- Tema escuro por padrão (economia de bateria em telas OLED) e respeito a `prefers-reduced-motion`.
- Hospedagem estática (GitHub Pages), que exige menos infraestrutura que servidores dinâmicos.
- Funciona bem em conexões lentas, o que importa em regiões com internet limitada.
